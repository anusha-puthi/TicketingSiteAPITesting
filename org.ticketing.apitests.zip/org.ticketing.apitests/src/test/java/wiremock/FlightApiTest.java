package wiremock;


import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import static org.junit.Assert.assertEquals;
//import static org.hamcrest.Matchers.equalTo;
//import static org.hamcrest.MatcherAssert.assertThat;

public class FlightApiTest {
    private static final int WIREMOCK_PORT = 8089;

    @BeforeClass
    public static void setup() {
        ExampleWireMock.setup();
        RestAssured.port = WIREMOCK_PORT;
    }

    @AfterClass
    public static void tearDown() {
    	ExampleWireMock.tearDown();
    }

    @Test
    public void testGetFlights() {
        Response response = RestAssured.get("/flights");

        // Assert the response status code is 200
        assertEquals(200, response.getStatusCode());

        // Assert the response contains the flight with flight number "AB123"
        String flightNumber = response.jsonPath().getString("flightNumber[0]");
        assertEquals("AB123", flightNumber);
    }
}



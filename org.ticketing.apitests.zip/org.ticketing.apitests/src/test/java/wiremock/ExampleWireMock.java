package wiremock;

//import org.junit.AfterClass;
//import org.junit.BeforeClass;
//import org.junit.Test;
//import io.restassured.RestAssured;
//import io.restassured.response.Response;
//import static org.hamcrest.Matchers.equalTo;
//import static org.hamcrest.MatcherAssert.assertThat;
//
//public class examplewiremock {
//    private static final int WIREMOCK_PORT = 8089;
//
//    @BeforeClass
//    public static void setup() {
//        FlightApi.setup();
//        RestAssured.port = WIREMOCK_PORT;
//    }
//
//    @AfterClass
//    public static void tearDown() {
//        FlightApi.tearDown();
//    }
//
//    @Test
//    public void testGetFlights() {
//        Response response = RestAssured.get("/flights");
//
//        // Assert the response status code is 200
//        assertThat(response.statusCode(), equalTo(200));
//
//        // Assert the response contains the flight with flight number "AB123"
//        response.then()
//                .body("flightNumber[0]", equalTo("AB123"));
//    }
//public class examplewiremock 
//{
//
//}


import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;

public class ExampleWireMock {
    private static final int WIREMOCK_PORT = 8089;
    private static WireMockServer wireMockServer;

    public static void setup() {
        wireMockServer = new WireMockServer(WIREMOCK_PORT);
        wireMockServer.start();
        WireMock.configureFor(WIREMOCK_PORT);
        stubGetFlights();
    }

    public static void tearDown() {
        wireMockServer.stop();
    }

    private static void stubGetFlights() {
        WireMock.stubFor(WireMock.get(WireMock.urlPathEqualTo("/flights"))
                .willReturn(WireMock.aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody("[{\"flightNumber\":\"AB123\",\"departure\":\"2023-07-20T12:00:00\",\"arrival\":\"2023-07-20T14:00:00\",\"price\":100.0}]")));
    }

    // Add more methods to interact with other endpoints if needed
}

